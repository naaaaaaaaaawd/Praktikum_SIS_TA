/*
  Muhamad Ridwan Pratama
  162024015
  Tugas Akhir 3
*/

import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Warung IS',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFBF5F8),
        primarySwatch: Colors.blue,
      ),
      home: const SplashScreen(),
    );
  }
}